* Fixed some bugs with mysql
* Added admin panel. Allows deletion of player or player jump.
================================
* Fixed bug with old mysql servers
* Fixed bug with empty names on sort orders
* Fixed bug with block jumps sort
* Fixed wrong num order in top
* Fixed CSS and HTML, now it's valid XHTML 1.0 Strict
* Fixed possible XSS inject in name
* Fixed motd scroll issue. Please add &from_game=true into cfg file for cvar kz_uq_url. It's temporary and will be autoadded in uq_jumpstats 2.20.
* Added search by name, ip, steamid. * is replaced by %. So you can search *ic* and it'll select all player with ic in nick.
  If you want to search by ip, type first two ip numbers like 12.21 or *12.32*
  If you want to search by steam, your search string must match num:num:num like STEAM_0:1:123 or 0:1:123
  In other cases, search will lookup names